with open('C:/Users/hs792/.gemini/antigravity/scratch/rezxmodz-portal/server.py', 'r', encoding='utf-8') as f:
    text = f.read()

target = "proto = 'https' if ('trycloudflare' in host_hdr or 'netlify' in host_hdr) else 'http'"
replacement = """forwarded_proto = self.headers.get('X-Forwarded-Proto', '').lower()
            if forwarded_proto:
                proto = forwarded_proto
            else:
                proto = 'https' if any(d in host_hdr for d in ('trycloudflare', 'netlify', 'onrender', 'koyeb', 'pages.dev', 'app')) else 'http'"""

if target in text:
    text = text.replace(target, replacement)
    print("Updated proto check for Render in server.py!")
else:
    print("Warning: target not found!")

with open('C:/Users/hs792/.gemini/antigravity/scratch/rezxmodz-portal/server.py', 'w', encoding='utf-8') as f:
    f.write(text)
